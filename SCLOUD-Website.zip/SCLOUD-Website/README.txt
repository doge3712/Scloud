SCLOUD – Website-Paket

So veröffentlichst du die Website kostenlos mit Netlify:
1. Öffne https://app.netlify.com/drop
2. Melde dich bei Netlify an (oder erstelle kostenlos ein Konto).
3. Entpacke SCLOUD-Website.zip auf deinem Gerät.
4. Ziehe den Ordner SCLOUD-Website mit der Datei index.html in Netlify Drop.
5. Netlify erstellt eine öffentliche Website-Adresse (z. B. zufälliger-name.netlify.app).

Die Website ist eine statische Seite und benötigt keinen eigenen Server.
Sie bettet den offiziellen SoundCloud-Player ein. Downloads werden nur über von SoundCloud bzw. Künstlern freigegebene Download-Funktionen unterstützt; geschützte Streams werden nicht extrahiert.
