SCLOUD – aktualisierte Website
Lade index.html in den Hauptordner deines GitHub-Repositories hoch und überschreibe die alte Datei. Vercel sollte automatisch neu deployen.
Die Seite nutzt SoundCloud oEmbed für Titel/Cover und den offiziellen SoundCloud-Player. Manche Tracks erlauben keine Einbettung oder liefern keine Metadaten.
