SCLOUD – Player-Fix v2
Lade index.html in den Hauptordner deines GitHub-Repositories und überschreibe die bisherige Datei. Vercel deployt anschließend automatisch.
Diese Version normalisiert m.soundcloud.com-Links und verwendet den offiziellen iframe-Code aus SoundCloud oEmbed. Falls SoundCloud für einen Track kein Embed bereitstellt, zeigt SCLOUD eine verständliche Meldung.
